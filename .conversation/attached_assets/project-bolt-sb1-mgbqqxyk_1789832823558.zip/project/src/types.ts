export type AppState = 'landing' | 'dashboard';

export interface Skill {
  name: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
}

export interface ExperienceEntry {
  role: string;
  company: string;
  duration: string;
  summary: string;
}

export interface EducationEntry {
  degree: string;
  institution: string;
  year: string;
}

export interface SkillGap {
  skill: string;
  importance: 'Critical' | 'Important' | 'Recommended';
  current_level: number;
  target_level: number;
}

export interface RoadmapPhase {
  phase: string;
  title: string;
  duration: string;
  status: 'upcoming' | 'active' | 'completed';
  modules: string[];
}

export interface AnalysisData {
  candidate_skills: Skill[];
  experience: ExperienceEntry[];
  education: EducationEntry[];
  required_skills: Skill[];
  skill_gaps: SkillGap[];
}

export interface AnalysisResult {
  career: string;
  resumeName: string;
  submittedAt: string;
  data: AnalysisData | null;
  error?: string;
}
