import { useState } from 'react';
import Landing from '@/components/Landing';
import Dashboard from '@/components/Dashboard';
import { extractResumeText } from '@/lib/resume';
import { analyzeCareer } from '@/lib/analyze';
import type { AppState, AnalysisResult, AnalysisData } from '@/types';

export default function App() {
  const [view, setView] = useState<AppState>('landing');
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);

  const handleAnalyze = async (career: string, file: File) => {
    const resumeName = file.name;
    const result: AnalysisResult = {
      career,
      resumeName,
      submittedAt: new Date().toLocaleString(),
      data: null,
    };

    // Move to dashboard immediately so the user sees the analyzing state
    setAnalysis(result);
    setView('dashboard');

    try {
      const resumeText = await extractResumeText(file);
      if (!resumeText || resumeText.trim().length < 20) {
        throw new Error('Could not extract enough text from the resume. Please try a different file.');
      }

      const data: AnalysisData = await analyzeCareer(career, resumeText);
      setAnalysis({ ...result, data });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong during analysis.';
      setAnalysis({ ...result, error: message });
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0b12] text-slate-200">
      {view === 'landing' && <Landing onStart={() => setView('dashboard')} onAnalyze={handleAnalyze} />}
      {view === 'dashboard' && (
        <Dashboard
          analysis={analysis}
          onBack={() => setView('landing')}
        />
      )}
    </div>
  );
}
