import { useState, useRef, useCallback } from 'react';
import {
  Sparkles,
  FileText,
  Rocket,
  ArrowRight,
  Brain,
  Target,
  TrendingUp,
  CheckCircle2,
  Upload,
  X,
  Compass,
} from 'lucide-react';

interface LandingProps {
  onStart: () => void;
  onAnalyze: (career: string, file: File) => void;
}

const CAREER_SUGGESTIONS = [
  'AI Engineer',
  'Machine Learning Engineer',
  'Data Scientist',
  'LLM Application Developer',
  'AI Research Scientist',
  'MLOps Engineer',
];

const FEATURES = [
  {
    icon: Brain,
    title: 'Skill Analysis',
    desc: 'Upload your resume and let EduPath map every skill you already have with precision.',
  },
  {
    icon: Target,
    title: 'Gap Identification',
    desc: 'See exactly what separates you from your target career — no guesswork, no fluff.',
  },
  {
    icon: Compass,
    title: 'Personalized Roadmap',
    desc: 'Get a step-by-step learning path tailored to your background and career goals.',
  },
  {
    icon: TrendingUp,
    title: 'Adaptive Progress',
    desc: 'Your roadmap adapts as you learn, prioritizing what matters most at each stage.',
  },
];

const STEPS = [
  { n: '01', title: 'Set your target', desc: 'Enter the AI career you want to pursue.' },
  { n: '02', title: 'Upload your resume', desc: 'Share your current skills and experience.' },
  { n: '03', title: 'Analyze', desc: 'EduPath maps your skills and identifies gaps.' },
  { n: '04', title: 'Learn & adapt', desc: 'Follow a roadmap that evolves with your progress.' },
];

export default function Landing({ onStart, onAnalyze }: LandingProps) {
  const [career, setCareer] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileName = file?.name ?? null;

  const handleFile = useCallback((f: File | null) => {
    if (f) {
      setFile(f);
      setError(null);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  }, [handleFile]);

  const handleAnalyzeClick = async () => {
    if (!career.trim() || !file) return;
    setAnalyzing(true);
    setError(null);
    onAnalyze(career.trim(), file);
  };

  const canAnalyze = career.trim() && file && !analyzing;

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background layers */}
      <div className="fixed inset-0 bg-grid pointer-events-none" />
      <div className="fixed inset-0 bg-radial-glow pointer-events-none" />
      <div className="fixed top-20 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px] animate-pulse-glow pointer-events-none" />
      <div className="fixed top-40 right-1/4 w-80 h-80 bg-cyan-500/15 rounded-full blur-[100px] animate-pulse-glow pointer-events-none" style={{ animationDelay: '2s' }} />

      {/* Nav */}
      <nav className="relative z-20 max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/30">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-semibold text-white tracking-tight">EduPath</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm text-slate-400">
          <a href="#how" className="hover:text-white transition-colors">How it works</a>
          <a href="#features" className="hover:text-white transition-colors">Features</a>
        </div>
        <button
          onClick={onStart}
          className="text-sm font-medium text-white/90 hover:text-white border border-white/10 hover:border-white/20 px-4 py-2 rounded-lg transition-all"
        >
          Dashboard
        </button>
      </nav>

      {/* Hero */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 pt-12 pb-20">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-medium mb-6 animate-slide-up">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
            Agentic AI Hackathon Build
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-white leading-[1.1] tracking-tight animate-slide-up" style={{ animationDelay: '0.05s' }}>
            Your AI career,
            <br />
            <span className="text-gradient">mapped from here</span>
            <br />
            to hired.
          </h1>
          <p className="mt-6 text-lg text-slate-400 leading-relaxed max-w-xl animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Enter your target career, upload your resume, and EduPath analyzes your skills,
            identifies the gaps, and builds a learning roadmap that adapts as you grow.
          </p>
        </div>

        {/* Input panel */}
        <div className="mt-10 max-w-2xl glass rounded-2xl p-6 md:p-7 animate-slide-up" style={{ animationDelay: '0.15s' }}>
          <div className="space-y-5">
            {/* Career input */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Target career
              </label>
              <div className="relative">
                <Target className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" style={{ width: 18, height: 18 }} />
                <input
                  type="text"
                  value={career}
                  onChange={(e) => setCareer(e.target.value)}
                  placeholder="e.g. AI Engineer"
                  className="w-full bg-[#0e0f1a] border border-white/10 focus:border-indigo-500/50 rounded-xl pl-11 pr-4 py-3 text-white placeholder-slate-500 outline-none transition-all focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                {CAREER_SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => setCareer(s)}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                      career === s
                        ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-300'
                        : 'bg-white/[0.03] border-white/10 text-slate-400 hover:border-white/20 hover:text-slate-300'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Resume upload */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Upload resume
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.doc,.docx,.txt"
                className="hidden"
                onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
              />
              {fileName ? (
                <div className="flex items-center justify-between bg-[#0e0f1a] border border-indigo-500/30 rounded-xl px-4 py-3.5">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-indigo-500/15 flex items-center justify-center flex-shrink-0">
                      <FileText className="text-indigo-400" style={{ width: 18, height: 18 }} />
                    </div>
                    <span className="text-sm text-slate-200 truncate">{fileName}</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  </div>
                  <button
                    onClick={() => { setFile(null); if (fileInputRef.current) fileInputRef.current.value = ''; }}
                    className="text-slate-500 hover:text-slate-300 transition-colors flex-shrink-0 ml-2"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                  onDragLeave={() => setDragging(false)}
                  onDrop={handleDrop}
                  className={`cursor-pointer rounded-xl border border-dashed px-4 py-8 text-center transition-all ${
                    dragging
                      ? 'border-indigo-500/60 bg-indigo-500/10'
                      : 'border-white/10 hover:border-white/20 bg-[#0e0f1a] hover:bg-[#12131f]'
                  }`}
                >
                  <Upload className={`w-7 h-7 mx-auto mb-2.5 transition-colors ${dragging ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <p className="text-sm text-slate-400">
                    <span className="text-indigo-400 font-medium">Click to upload</span> or drag & drop
                  </p>
                  <p className="text-xs text-slate-600 mt-1">PDF, DOCX, or TXT</p>
                </div>
              )}
            </div>

            {/* Error */}
            {error && (
              <p className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-2.5">
                {error}
              </p>
            )}

            {/* Analyze button */}
            <button
              onClick={handleAnalyzeClick}
              disabled={!canAnalyze}
              className={`w-full flex items-center justify-center gap-2 rounded-xl py-3.5 font-medium transition-all ${
                canAnalyze
                  ? 'bg-gradient-to-r from-indigo-500 to-cyan-500 text-white shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 hover:scale-[1.01]'
                  : 'bg-white/[0.04] text-slate-600 cursor-not-allowed border border-white/5'
              }`}
            >
              {analyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Rocket style={{ width: 18, height: 18 }} />
                  Analyze my path
                </>
              )}
            </button>
            {!canAnalyze && !analyzing && (
              <p className="text-xs text-slate-600 text-center -mt-2">
                Enter a career and upload a resume to continue
              </p>
            )}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="relative z-10 max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white tracking-tight">How it works</h2>
          <p className="text-slate-400 mt-3">Four steps from where you are to where you want to be.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {STEPS.map((step, i) => (
            <div
              key={step.n}
              className="glass-card rounded-2xl p-6 animate-slide-up"
              style={{ animationDelay: `${i * 0.08}s` }}
            >
              <div className="text-2xl font-bold text-gradient mb-3">{step.n}</div>
              <h3 className="text-white font-semibold mb-1.5">{step.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative z-10 max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white tracking-tight">Built for the AI career journey</h2>
          <p className="text-slate-400 mt-3">Everything you need to close the gap between today and your target role.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {FEATURES.map((f, i) => (
            <div
              key={f.title}
              className="glass-card rounded-2xl p-7 flex gap-5 animate-slide-up"
              style={{ animationDelay: `${i * 0.08}s` }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500/20 to-cyan-500/20 border border-white/10 flex items-center justify-center flex-shrink-0">
                <f.icon className="w-5 h-5 text-indigo-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold mb-1.5">{f.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <div className="glass rounded-3xl p-10 md:p-14 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/10 to-cyan-500/10" />
          <div className="relative">
            <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">Ready to find your path?</h2>
            <p className="text-slate-400 mt-4 max-w-lg mx-auto">
              Start by telling EduPath where you want to go. We'll handle the mapping.
            </p>
            <button
              onClick={() => {
                document.querySelector('input')?.focus();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="mt-8 inline-flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-medium px-6 py-3.5 rounded-xl shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 hover:scale-[1.02] transition-all"
            >
              Get started
              <ArrowRight style={{ width: 18, height: 18 }} />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 mt-8">
        <div className="max-w-7xl mx-auto px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm text-slate-500">EduPath — Agentic AI Hackathon</span>
          </div>
          <p className="text-xs text-slate-600">Built with React, TypeScript & Tailwind</p>
        </div>
      </footer>
    </div>
  );
}
