import { useState, useRef, useCallback } from 'react';
import {
  Sparkles,
  FileText,
  Rocket,
  Target,
  Upload,
  X,
  CheckCircle2,
  Brain,
  Compass,
  AlertTriangle,
  TrendingUp,
  ArrowLeft,
  Circle,
  Clock,
  BookOpen,
  Loader2,
  GraduationCap,
  Briefcase,
  AlertCircle,
} from 'lucide-react';
import type { AnalysisResult, Skill, SkillGap } from '@/types';
import { extractResumeText } from '@/lib/resume';
import { analyzeCareer } from '@/lib/analyze';
import type { AnalysisData } from '@/types';

interface DashboardProps {
  analysis: AnalysisResult | null;
  onBack: () => void;
}

const IMPORTANCE_STYLES: Record<SkillGap['importance'], string> = {
  Critical: 'bg-red-500/10 text-red-400 border-red-500/20',
  Important: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  Recommended: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
};

const LEVEL_STYLES: Record<Skill['level'], string> = {
  Advanced: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
  Intermediate: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/20',
  Beginner: 'bg-slate-500/15 text-slate-400 border-slate-500/20',
};

export default function Dashboard({ analysis, onBack }: DashboardProps) {
  const [career, setCareer] = useState(analysis?.career ?? '');
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [analyzing, setAnalyzing] = useState(!analysis?.data && !analysis?.error && !!analysis);
  const [data, setData] = useState<AnalysisData | null>(analysis?.data ?? null);
  const [error, setError] = useState<string | null>(analysis?.error ?? null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileName = file?.name ?? analysis?.resumeName ?? null;

  const handleFile = useCallback((f: File | null) => {
    if (f) {
      setFile(f);
      setError(null);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  }, [handleFile]);

  const handleAnalyze = async () => {
    if (!career.trim() || !file) return;
    setAnalyzing(true);
    setError(null);
    setData(null);

    try {
      const resumeText = await extractResumeText(file);
      if (!resumeText || resumeText.trim().length < 20) {
        throw new Error('Could not extract enough text from the resume. Please try a different file.');
      }
      const result = await analyzeCareer(career.trim(), resumeText);
      setData(result);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong during analysis.';
      setError(message);
    } finally {
      setAnalyzing(false);
    }
  };

  const canAnalyze = career.trim() && file && !analyzing;

  const skills = data?.candidate_skills ?? [];
  const gaps = data?.skill_gaps ?? [];
  const requiredSkills = data?.required_skills ?? [];
  const experience = data?.experience ?? [];
  const education = data?.education ?? [];

  const overallProgress = gaps.length > 0
    ? Math.round((gaps.reduce((acc, g) => acc + g.current_level / g.target_level, 0) / gaps.length) * 100)
    : 0;

  const hasResults = !!data && !analyzing;
  const showEmpty = !hasResults && !analyzing && !error;

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="fixed inset-0 bg-grid pointer-events-none opacity-60" />
      <div className="fixed top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 glass border-r border-white/5 hidden lg:flex flex-col z-20">
        <div className="p-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-semibold text-white tracking-tight">EduPath</span>
          </div>
        </div>

        <nav className="px-3 space-y-1 flex-1">
          {[
            { icon: Target, label: 'Overview', active: true },
            { icon: Brain, label: 'Skills' },
            { icon: AlertTriangle, label: 'Skill Gaps' },
            { icon: Compass, label: 'Roadmap' },
            { icon: TrendingUp, label: 'Progress' },
          ].map((item) => (
            <button
              key={item.label}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                item.active
                  ? 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.03]'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4">
          <button
            onClick={onBack}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm text-slate-400 hover:text-slate-200 hover:bg-white/[0.03] transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to home
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="lg:ml-64 relative z-10">
        {/* Top bar */}
        <header className="sticky top-0 z-30 glass border-b border-white/5 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3 lg:hidden">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-white">EduPath</span>
          </div>
          <div className="hidden lg:block">
            <h1 className="text-lg font-semibold text-white">
              {career ? `Path to ${career}` : 'Your Learning Dashboard'}
            </h1>
            {analysis?.submittedAt && (
              <p className="text-xs text-slate-500 mt-0.5">Last analyzed: {analysis.submittedAt}</p>
            )}
          </div>
          <button
            onClick={onBack}
            className="lg:hidden text-sm text-slate-400 hover:text-white transition-colors flex items-center gap-1.5"
          >
            <ArrowLeft className="w-4 h-4" />
            Home
          </button>
        </header>

        <div className="px-6 py-8 max-w-5xl mx-auto space-y-8">
          {/* Input panel */}
          <section className="glass rounded-2xl p-6 animate-fade-in">
            <div className="flex items-center gap-2 mb-5">
              <Target className="text-indigo-400" style={{ width: 18, height: 18 }} />
              <h2 className="text-sm font-semibold text-white uppercase tracking-wide">Career Setup</h2>
            </div>

            <div className="grid md:grid-cols-2 gap-5">
              {/* Career */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Target career</label>
                <div className="relative">
                  <Target className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" style={{ width: 18, height: 18 }} />
                  <input
                    type="text"
                    value={career}
                    onChange={(e) => setCareer(e.target.value)}
                    placeholder="e.g. AI Engineer"
                    className="w-full bg-[#0e0f1a] border border-white/10 focus:border-indigo-500/50 rounded-xl pl-11 pr-4 py-3 text-white placeholder-slate-500 outline-none transition-all focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* Resume */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Resume</label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx,.txt"
                  className="hidden"
                  onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
                />
                {fileName ? (
                  <div className="flex items-center justify-between bg-[#0e0f1a] border border-indigo-500/30 rounded-xl px-4 py-3 h-[50px]">
                    <div className="flex items-center gap-3 min-w-0">
                      <FileText className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                      <span className="text-sm text-slate-200 truncate">{fileName}</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    </div>
                    <button
                      onClick={() => { setFile(null); if (fileInputRef.current) fileInputRef.current.value = ''; }}
                      className="text-slate-500 hover:text-slate-300 transition-colors flex-shrink-0 ml-2"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                    onDragLeave={() => setDragging(false)}
                    onDrop={handleDrop}
                    className={`cursor-pointer rounded-xl border border-dashed px-4 h-[50px] flex items-center justify-center gap-2 text-sm transition-all ${
                      dragging
                        ? 'border-indigo-500/60 bg-indigo-500/10'
                        : 'border-white/10 hover:border-white/20 bg-[#0e0f1a]'
                    }`}
                  >
                    <Upload className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-400">Upload resume</span>
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={!canAnalyze}
              className={`mt-5 w-full md:w-auto flex items-center justify-center gap-2 rounded-xl px-6 py-3 font-medium transition-all ${
                canAnalyze
                  ? 'bg-gradient-to-r from-indigo-500 to-cyan-500 text-white shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40'
                  : 'bg-white/[0.04] text-slate-600 cursor-not-allowed'
              }`}
            >
              {analyzing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Rocket className="w-4 h-4" />
                  {hasResults ? 'Re-analyze' : 'Analyze my path'}
                </>
              )}
            </button>
          </section>

          {/* Analyzing state */}
          {analyzing && <AnalyzingState />}

          {/* Error state */}
          {error && !analyzing && <ErrorState message={error} />}

          {/* Results */}
          {hasResults && (
            <>
              {/* Progress overview */}
              <section className="glass rounded-2xl p-6 animate-slide-up">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-lg font-semibold text-white">Overall Readiness</h2>
                    <p className="text-sm text-slate-500 mt-0.5">Progress toward {career}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-gradient">{overallProgress}%</div>
                  </div>
                </div>
                <div className="h-2.5 bg-[#0e0f1a] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full transition-all duration-1000"
                    style={{ width: `${overallProgress}%` }}
                  />
                </div>
                <div className="grid grid-cols-3 gap-4 mt-5">
                  <StatCard label="Skills mapped" value={String(skills.length)} icon={Brain} />
                  <StatCard label="Gaps identified" value={String(gaps.length)} icon={AlertTriangle} />
                  <StatCard label="Required skills" value={String(requiredSkills.length)} icon={Target} />
                </div>
              </section>

              {/* Experience + Education (two-col on desktop) */}
              {(experience.length > 0 || education.length > 0) && (
                <div className="grid md:grid-cols-2 gap-6">
                  {experience.length > 0 && (
                    <InfoSection icon={Briefcase} title="Experience" subtitle="Work history from your resume">
                      <div className="space-y-3">
                        {experience.map((exp, i) => (
                          <div key={i} className="bg-[#0e0f1a] rounded-xl px-4 py-3 border border-white/5">
                            <div className="flex items-start justify-between gap-2 flex-wrap">
                              <p className="text-sm font-medium text-white">{exp.role}</p>
                              <span className="text-xs text-slate-500">{exp.duration}</span>
                            </div>
                            <p className="text-xs text-indigo-400 mt-0.5">{exp.company}</p>
                            {exp.summary && <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">{exp.summary}</p>}
                          </div>
                        ))}
                      </div>
                    </InfoSection>
                  )}

                  {education.length > 0 && (
                    <InfoSection icon={GraduationCap} title="Education" subtitle="Academic background">
                      <div className="space-y-3">
                        {education.map((edu, i) => (
                          <div key={i} className="bg-[#0e0f1a] rounded-xl px-4 py-3 border border-white/5">
                            <p className="text-sm font-medium text-white">{edu.degree}</p>
                            <p className="text-xs text-indigo-400 mt-0.5">{edu.institution}</p>
                            {edu.year && <p className="text-xs text-slate-500 mt-0.5">{edu.year}</p>}
                          </div>
                        ))}
                      </div>
                    </InfoSection>
                  )}
                </div>
              )}

              {/* Skills */}
              <InfoSection icon={Brain} title="Your Skills" subtitle="Skills detected from your resume">
                {skills.length > 0 ? (
                  <div className="grid sm:grid-cols-2 gap-3">
                    {skills.map((skill) => (
                      <div key={skill.name} className="flex items-center justify-between bg-[#0e0f1a] rounded-xl px-4 py-3 border border-white/5">
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-white truncate">{skill.name}</p>
                          <p className="text-xs text-slate-500 mt-0.5">{skill.category}</p>
                        </div>
                        <span className={`text-xs px-2.5 py-1 rounded-md border flex-shrink-0 ${LEVEL_STYLES[skill.level]}`}>
                          {skill.level}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyInline text="No skills detected from your resume." />
                )}
              </InfoSection>

              {/* Required skills */}
              {requiredSkills.length > 0 && (
                <InfoSection icon={Target} title="Required Skills" subtitle={`What you need for ${career}`}>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {requiredSkills.map((skill) => (
                      <div key={skill.name} className="flex items-center justify-between bg-[#0e0f1a] rounded-xl px-4 py-3 border border-white/5">
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-white truncate">{skill.name}</p>
                          <p className="text-xs text-slate-500 mt-0.5">{skill.category}</p>
                        </div>
                        <span className={`text-xs px-2.5 py-1 rounded-md border flex-shrink-0 ${LEVEL_STYLES[skill.level]}`}>
                          {skill.level}
                        </span>
                      </div>
                    ))}
                  </div>
                </InfoSection>
              )}

              {/* Skill Gaps */}
              <InfoSection icon={AlertTriangle} title="Skill Gaps" subtitle="What you need to reach your target career">
                {gaps.length > 0 ? (
                  <div className="space-y-3">
                    {gaps.map((gap) => (
                      <div key={gap.skill} className="bg-[#0e0f1a] rounded-xl px-4 py-4 border border-white/5">
                        <div className="flex items-center justify-between mb-2.5">
                          <p className="text-sm font-medium text-white">{gap.skill}</p>
                          <span className={`text-xs px-2.5 py-1 rounded-md border ${IMPORTANCE_STYLES[gap.importance]}`}>
                            {gap.importance}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div
                              key={i}
                              className={`flex-1 h-2 rounded-full ${
                                i < gap.current_level
                                  ? 'bg-indigo-500/60'
                                  : i < gap.target_level
                                  ? 'bg-white/10'
                                  : 'bg-white/[0.03]'
                              }`}
                            />
                          ))}
                          <span className="text-xs text-slate-500 ml-2 flex-shrink-0 w-12 text-right">
                            {gap.current_level}/{gap.target_level}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyInline text="No skill gaps identified — you're well matched!" />
                )}
              </InfoSection>

              {/* Roadmap placeholder */}
              <InfoSection icon={Compass} title="Learning Roadmap" subtitle="A phased plan tailored to your gaps">
                <div className="relative">
                  <div className="absolute left-[15px] top-2 bottom-2 w-px bg-white/10" />
                  <div className="space-y-4">
                    {gaps
                      .filter((g) => g.importance === 'Critical')
                      .slice(0, 1)
                      .map((g, idx) => (
                        <RoadmapItem
                          key={g.skill}
                          phase={`Phase ${idx + 1}`}
                          title={`Master ${g.skill}`}
                          duration="4-6 weeks"
                          status="active"
                          modules={['Fundamentals', 'Hands-on Practice', 'Project Building']}
                        />
                      ))}
                    {gaps
                      .filter((g) => g.importance !== 'Critical')
                      .slice(0, 3)
                      .map((g, idx) => (
                        <RoadmapItem
                          key={g.skill}
                          phase={`Phase ${idx + 2}`}
                          title={`Build ${g.skill} skills`}
                          duration="3-5 weeks"
                          status="upcoming"
                          modules={['Core Concepts', 'Applied Exercises']}
                        />
                      ))}
                    {gaps.length === 0 && (
                      <div className="relative flex gap-4">
                        <div className="relative z-10 w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 border-2 bg-indigo-500/20 border-indigo-500">
                          <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                        </div>
                        <div className="flex-1 bg-[#0e0f1a] rounded-xl px-5 py-4 border border-white/5">
                          <h4 className="text-sm font-semibold text-white">You're ready!</h4>
                          <p className="text-xs text-slate-400 mt-1">No critical gaps — focus on advanced projects and portfolio building.</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </InfoSection>
            </>
          )}

          {/* Empty state */}
          {showEmpty && <EmptyState />}
        </div>
      </main>
    </div>
  );
}

function StatCard({ label, value, icon: Icon }: { label: string; value: string; icon: React.ElementType }) {
  return (
    <div className="bg-[#0e0f1a] rounded-xl px-4 py-3.5 border border-white/5">
      <div className="flex items-center gap-2 text-slate-500 mb-1">
        <Icon className="w-3.5 h-3.5" />
        <span className="text-xs">{label}</span>
      </div>
      <div className="text-2xl font-bold text-white">{value}</div>
    </div>
  );
}

function InfoSection({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: React.ElementType;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <section className="glass rounded-2xl p-6 animate-slide-up">
      <div className="flex items-center gap-2.5 mb-5">
        <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
          <Icon className="w-4 h-4 text-indigo-400" />
        </div>
        <div>
          <h2 className="text-base font-semibold text-white">{title}</h2>
          <p className="text-xs text-slate-500">{subtitle}</p>
        </div>
      </div>
      {children}
    </section>
  );
}

function RoadmapItem({
  phase,
  title,
  duration,
  status,
  modules,
}: {
  phase: string;
  title: string;
  duration: string;
  status: 'upcoming' | 'active' | 'completed';
  modules: string[];
}) {
  return (
    <div className="relative flex gap-4">
      <div className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 border-2 ${
        status === 'active'
          ? 'bg-indigo-500/20 border-indigo-500'
          : status === 'completed'
          ? 'bg-emerald-500/20 border-emerald-500'
          : 'bg-[#0e0f1a] border-white/15'
      }`}>
        {status === 'completed' ? (
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        ) : status === 'active' ? (
          <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" style={{ animationDuration: '3s' }} />
        ) : (
          <Circle className="w-3 h-3 text-slate-600" />
        )}
      </div>
      <div className="flex-1 bg-[#0e0f1a] rounded-xl px-5 py-4 border border-white/5 hover:border-indigo-500/20 transition-colors">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <span className="text-xs text-indigo-400 font-medium">{phase}</span>
            <h4 className="text-sm font-semibold text-white mt-0.5">{title}</h4>
          </div>
          <span className="flex items-center gap-1.5 text-xs text-slate-500">
            <Clock className="w-3.5 h-3.5" />
            {duration}
          </span>
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {modules.map((m) => (
            <span key={m} className="text-xs px-2.5 py-1 rounded-lg bg-white/[0.03] border border-white/5 text-slate-400 flex items-center gap-1.5">
              <BookOpen className="w-3 h-3 text-slate-600" />
              {m}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function EmptyInline({ text }: { text: string }) {
  return <p className="text-sm text-slate-500 text-center py-4">{text}</p>;
}

function AnalyzingState() {
  return (
    <div className="glass rounded-2xl p-16 text-center animate-fade-in">
      <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center mx-auto mb-5">
        <Loader2 className="w-7 h-7 text-indigo-400 animate-spin" />
      </div>
      <h3 className="text-lg font-semibold text-white">Analyzing your resume</h3>
      <p className="text-sm text-slate-500 mt-2 max-w-sm mx-auto">
        Extracting skills, comparing against your target career, and identifying gaps with AI...
      </p>
    </div>
  );
}

function ErrorState({ message }: { message: string }) {
  return (
    <div className="glass rounded-2xl p-10 text-center animate-fade-in border-red-500/20">
      <div className="w-14 h-14 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4">
        <AlertCircle className="w-6 h-6 text-red-400" />
      </div>
      <h3 className="text-base font-semibold text-white">Analysis failed</h3>
      <p className="text-sm text-slate-400 mt-2 max-w-md mx-auto">{message}</p>
      <p className="text-xs text-slate-600 mt-3">Try re-uploading your resume and clicking Analyze again.</p>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="glass rounded-2xl p-16 text-center animate-fade-in">
      <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center mx-auto mb-5">
        <Compass className="w-7 h-7 text-indigo-400" />
      </div>
      <h3 className="text-lg font-semibold text-white">Ready to map your path</h3>
      <p className="text-sm text-slate-500 mt-2 max-w-sm mx-auto">
        Enter your target career, upload your resume, and hit analyze to see your skills, gaps, and personalized roadmap.
      </p>
    </div>
  );
}
