import type { AnalysisData } from '@/types';

interface EdgeFunctionResponse {
  error?: string;
  // The Gemini JSON shape is passed through directly
  candidate_skills?: AnalysisData['candidate_skills'];
  experience?: AnalysisData['experience'];
  education?: AnalysisData['education'];
  required_skills?: AnalysisData['required_skills'];
  skill_gaps?: AnalysisData['skill_gaps'];
}

export async function analyzeCareer(
  career: string,
  resumeText: string
): Promise<AnalysisData> {
  const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-career`;

  const res = await fetch(functionUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify({ career, resumeText }),
  });

  const body: EdgeFunctionResponse = await res.json().catch(() => ({}));

  if (!res.ok) {
    const msg = body.error || `Analysis failed (HTTP ${res.status})`;
    throw new Error(msg);
  }

  if (body.error) {
    throw new Error(body.error);
  }

  // Validate the shape before returning
  if (!body.candidate_skills || !body.skill_gaps) {
    throw new Error('Received an incomplete analysis from the AI. Please try again.');
  }

  return {
    candidate_skills: body.candidate_skills,
    experience: body.experience ?? [],
    education: body.education ?? [],
    required_skills: body.required_skills ?? [],
    skill_gaps: body.skill_gaps,
  };
}
