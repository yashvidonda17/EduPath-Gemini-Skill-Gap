const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AnalysisPayload {
  career: string;
  resumeText: string;
}

interface GeminiResponse {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
  error?: { message: string };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { career, resumeText } = (await req.json()) as AnalysisPayload;

    if (!career || !resumeText) {
      return new Response(
        JSON.stringify({ error: "Missing career or resumeText" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "Gemini API key is not configured. Add GEMINI_API_KEY as an edge function secret." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const prompt = `You are an expert career advisor and technical recruiter. Analyze the candidate's resume against the target career "${career}".

Resume text:
"""
${resumeText}
"""

Return ONLY valid JSON (no markdown, no code fences) with this exact structure:
{
  "candidate_skills": [{ "name": "string", "level": "Beginner|Intermediate|Advanced", "category": "string" }],
  "experience": [{ "role": "string", "company": "string", "duration": "string", "summary": "string" }],
  "education": [{ "degree": "string", "institution": "string", "year": "string" }],
  "required_skills": [{ "name": "string", "level": "Beginner|Intermediate|Advanced", "category": "string" }],
  "skill_gaps": [{ "skill": "string", "importance": "Critical|Important|Recommended", "current_level": number(0-5), "target_level": number(1-5) }]
}

Guidelines:
- candidate_skills: extract skills explicitly mentioned or strongly implied in the resume
- required_skills: skills typically required for the target career "${career}"
- skill_gaps: skills in required_skills that are missing or underdeveloped in candidate_skills
- current_level: 0 if not present, 1-3 based on resume evidence
- target_level: 3-5 based on importance for the career
- importance: Critical = must-have, Important = strongly preferred, Recommended = nice-to-have`;

    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    const geminiRes = await fetch(geminiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.4,
          responseMimeType: "application/json",
        },
      }),
    });

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      return new Response(
        JSON.stringify({ error: `Gemini API error (${geminiRes.status}): ${errText}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const geminiData: GeminiResponse = await geminiRes.json();

    if (geminiData.error) {
      return new Response(
        JSON.stringify({ error: geminiData.error.message }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const rawText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!rawText) {
      return new Response(
        JSON.stringify({ error: "Gemini returned no content" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      const cleaned = rawText.replace(/```json/gi, "").replace(/```/g, "").trim();
      parsed = JSON.parse(cleaned);
    }

    return new Response(
      JSON.stringify(parsed),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
